//该模块是用于定义action对象中type类型的常量值，防止编译时出错

export const INCREMENT = 'increment'
export const DECREMENT = 'decrement'